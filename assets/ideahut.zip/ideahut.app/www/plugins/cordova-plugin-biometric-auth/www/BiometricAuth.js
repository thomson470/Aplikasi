cordova.define("cordova-plugin-biometric-auth.BiometricAuth", function(require, exports, module) {
"use strict";
var exec = require('cordova/exec');

var BiometricAuth = {
	isAvailable: function (successCallback, errorCallback, args) {
		exec(successCallback, errorCallback, "BiometricAuth", "isAvailable", [args]);
	},
	authenticate: function (successCallback, errorCallback, args) {
		exec(successCallback, errorCallback, "BiometricAuth", "authenticate", [args]);
	}
};

module.exports = BiometricAuth;

});
