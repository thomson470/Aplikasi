const e=""+new URL("noimage-DkFwksQu.png",import.meta.url).href;export{e as _};
