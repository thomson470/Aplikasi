const t=""+new URL("nodata-lsWswLxJ.png",import.meta.url).href;export{t as _};
